/* cm.c — H2/H2b: context-mixing compressor on the base-8 digit tree (Base-8 Hutter project).
 *
 * Byte = three base-8 digits (3,3,2 bits, high first), each a binary tree, as in b8ac.c.
 * Models (inputs to the mixer):
 *   order-0 (direct, 512 node slots), hashed orders 1..6, word model
 *   (hash of current word's lower-cased letters + previous word's hash),
 *   match model (H2b, FLAGS bit4).
 * Each hashed model, at the start of every base-8 digit, selects one 8-slot bucket
 * from hash(context, digits already coded in this byte). Slot 0 of the bucket holds an
 * 8-bit check; on mismatch the bucket is reset (always-replace). Slots 1..7 are the
 * digit tree's internal nodes. So one table lookup per model per base-8 digit.
 * Counters: 16-bit prob + count, rate 1/(n+1.5), n capped at LIMIT.
 * Mixer input = stretch(p) in logit units (0 if the slot is new), plus a bias input.
 * Mixer: single-layer online logistic mixer (paq style), float weights,
 *   w += lr * (bit - p) * x. Weight set selected by node id (partial byte) or digit index.
 * Optional APM/SSE stage (flag): interpolated 33-bucket APM on (order-1 byte, node),
 *   output averaged with the mixer output (paq/lpaq style).
 * Match model (FLAGS bit4): ring buffer of past bytes (2^BUFBITS) + hash table (2^MBITS)
 *   from hash(last MINLEN bytes) to the position that followed. Candidates are verified
 *   by comparing backwards. While the bits coded so far in this byte agree with the
 *   predicted byte, two inputs: +-stretch(p_correct[len bucket, expected bit]) and
 *   +-min(len,32)/8; else 0. Mixer weight sets x4 by match-length bucket.
 *
 * Techniques follow lpaq1 / paq8 (Matt Mahoney, GPL, http://mattmahoney.net/dc/;
 * paq8px https://github.com/hxim/paq8px): logistic mixing, stretch/squash, hashed context
 * buckets with checks, APM, match model. All code written fresh here.
 *
 * Usage: cm c|d in out [FLAGS] [TBITS]
 *   FLAGS bit0 = word model on, bit1 = mixer set by node id (else by digit index),
 *         bit2 = APM on, bit3 = mixer set also by count of seen order-2..6 slots (0..5),
 *         bit4 = match model on (+ mixer sets x4 by match length),
 *         bit5 = H3 Wuwei brain (brain.h) as an extra mixer input ("augment"),
 *         bit6 = with bit5: brain output replaces the logistic mixer output ("replace").
 *   Brain lr is compile-time (-DBLR=..., default 0.022): decoder must use the same build.
 *   Default FLAGS = 3, TBITS = 22 (buckets per model = 2^TBITS).
 * Archive: 1 byte FLAGS, [1 byte XF if FLAGS bit7], 1 byte TBITS, [9 bytes per-model table bits if XF bit2],
 *   8 bytes length (LE), coded stream.
 * P1.2: XF bit2 = per-model table sizes, taken from env CM_TB="o1,o2,o3,o4,o5,o6,word,mk0,mk1" (log2 buckets)
 *   when compressing and stored in the header (the decoder needs no env).
 * Note: MINLEN/MBITS/BUFBITS are compile-time; the decoder must be built with the same values.
 * B1 step 2: XF bit6 = frozen Wuwei brain (fbrain.h). 22,277 fp16 weights (44,554 bytes, env CM_BW at compress
 *   time) follow the 8 length bytes in the archive. Coded p' = squash(stretch(p) + y); the models, mixer and APM
 *   still learn from their own p, so the brain changes only the coded probability.
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <math.h>
#include <xmmintrin.h>

#ifndef LIMIT
#define LIMIT 12
#endif
#ifndef LR
#define LR 0.004f
#endif
#ifndef MINLEN
#define MINLEN 8   /* tuned on s10m: 4..32 tried, 8 best */
#endif
#ifndef MBITS
#define MBITS 22
#endif
#ifndef BUFBITS
#define BUFBITS 28
#endif
#ifndef MLIMIT
#define MLIMIT 255
#endif
static int16_t stretch_t[4096];
static int sq_t[4095];
static int SQ(int d){ if(d>2047)d=2047; if(d<-2047)d=-2047; return sq_t[d+2047]; }
static uint32_t recip[256];

static void init_tables(void) {
    for (int i = 0; i < 4095; i++) { int v = (int)(4096.0 / (1.0 + exp(-(i - 2047) / 256.0))); if (v < 1) v = 1; if (v > 4095) v = 4095; sq_t[i] = v; }
    int pi = 0;
    for (int x = -2047; x <= 2047; x++) { int v = SQ(x); for (int j = pi; j <= v; j++) stretch_t[j] = (int16_t)x; pi = v + 1; }
    for (int j = pi; j < 4096; j++) stretch_t[j] = 2047;
    for (int n = 0; n < 256; n++) recip[n] = (uint32_t)(65536.0 / (n + 1.5));
}

/* ---- arithmetic coder (same as b8ac.c) ---- */
typedef struct { uint32_t x1, x2, x; FILE *f; } AC;
static void enc_bit(AC *a, int p12, int bit) {
    uint32_t xmid = a->x1 + (uint32_t)(((uint64_t)(a->x2 - a->x1) * p12) >> 12);
    if (bit) a->x2 = xmid; else a->x1 = xmid + 1;
    while (((a->x1 ^ a->x2) & 0xff000000u) == 0) { putc(a->x2 >> 24, a->f); a->x1 <<= 8; a->x2 = (a->x2 << 8) | 255; }
}
static int dec_bit(AC *a, int p12) {
    uint32_t xmid = a->x1 + (uint32_t)(((uint64_t)(a->x2 - a->x1) * p12) >> 12);
    int bit = a->x <= xmid;
    if (bit) a->x2 = xmid; else a->x1 = xmid + 1;
    while (((a->x1 ^ a->x2) & 0xff000000u) == 0) {
        a->x1 <<= 8; a->x2 = (a->x2 << 8) | 255; int c = getc(a->f); a->x = (a->x << 8) | (uint32_t)(c == EOF ? 0 : c);
    }
    return bit;
}

/* ---- slots ---- */
typedef struct { uint16_t p; uint8_t n; } __attribute__((packed)) Slot;  /* 3 bytes */
static inline void slot_upd(Slot *s, int bit) {
    int p = s->p, target = bit ? 65535 : 0;
    p += (int)(((int64_t)(target - p) * recip[s->n]) >> 16);
    s->p = (uint16_t)p; if (s->n < LIMIT) s->n++;
}

#define NH 7          /* hashed models: orders 1..6, word */
#define NI (NH + 7 + 27) /* inputs: order-0, NH hashed, bias, 2 match, brain, 2 markup, 9 state-map, 9 slow, 9 confidence (later inputs are 0 when their flag is off) */
#define ISM (NH + 7)  /* P1.3: 9 state-map inputs (XF bit3) */
#define ISL (NH + 16) /* P1.3: 9 slow-counter inputs (XF bit4) */
#define ICF (NH + 25) /* P1.3: 9 confidence inputs (XF bit5) */
#define NM 9          /* models with slots: orders 1..6, word, markup 0, markup 1 */
#define IMK (NH + 5)  /* H4: two markup-model inputs, appended last so FLAGS <= 127 arithmetic is unchanged */
#define IBRAIN (NH + 4)
#define IBIAS (NH + 1)
static int FLAGS, TBITS, XF;  /* XF: extension byte (present when FLAGS bit7): bit0 markup models, bit1 text-mode mixer sets,
                                 bit2 (P1.2) per-model table bits: 9 bytes follow TBITS in the header */
static int TB[9];             /* P1.2: table bits per hashed model: orders 1..6, word, markup 0, markup 1 */
static Slot *H[NH];   /* each 2^TBITS buckets x 8 slots */
static Slot O0[512];
static Slot *bucket[NH];
static uint64_t hist;            /* last 8 bytes */
static uint32_t ctxh[NH];        /* per-byte context hashes */
static uint32_t wcur, wprev;     /* word hashes */
static float *Wt; static int NSETS, NIU;  /* NIU: inputs actually used (14 unless XF bit3/bit4) */
static float xin[NI];
static int wset;
/* APM */
static uint16_t *apm; static int apm_idx; static int apm_w;
static int pr_mix, pr_final;
static Slot *cur_slot[NH + 1];
/* match model */
#define BMASK ((1ULL << BUFBITS) - 1)
static uint8_t *mbuf; static uint32_t *mtab;
static uint64_t mpos, mptr;      /* bytes seen; position of predicted byte */
static int mlen, mexp, mvalid, mbitpos, mbit, mctx;
static Slot mst[64];
/* B1: feature dump (env CM_DUMP, compress only; does not change the archive) */
static FILE *dumpf; static float dfeat[16]; static uint64_t dcnt;
#include "brain.h"
#include "fbrain.h"   /* B1 step 2: frozen brain, XF bit6 */
static uint16_t fbh[FB_NPAR];
static inline uint32_t hash32_fwd(uint32_t x) { x ^= x >> 16; x *= 0x7feb352dU; x ^= x >> 15; x *= 0x846ca68bU; x ^= x >> 16; return x; }

/* ---- H4: wiki-markup state tracker (updated once per byte, same in encoder and decoder) ----
 * Stack of open constructs: 1 [[link, 2 {{template, 3 [ext link, 4 <tag (raw or &lt;), 5 single {, 6 {| table.
 * Toggles: in <text> (article body), in &lt;ref&gt;, italic/bold from runs of apostrophes.
 * Line class from the first byte of the line. */
enum { K_LINK = 1, K_TMPL, K_EXT, K_TAG, K_BR1, K_TABLE };
static uint8_t mk_st[16]; static int mk_sp, mk_intext, mk_inref, mk_ital, mk_bold, mk_apos, mk_lc, mk_linestart = 1;
static char mk_tag[12]; static int mk_tn, mk_tagraw, mk_intag;
static Slot *HX[2]; static Slot *bucketX[2]; static uint32_t ctxhX[2]; static Slot *cur_slotX[2];
static int mk_mode;
/* P1.3 counters: state map (XF bit3) and slow second probability per slot (XF bit4) */
static uint16_t smt[NM * 3 * 13 * 64]; static int sm_i[NM];
static uint16_t *H2[NH], *HX2[2], *bucket2[NM], *cur2[NM];
static inline int mk_top(void) { return mk_sp ? mk_st[mk_sp - 1] : 0; }
static inline void mk_push(int k) { if (mk_sp < 16) mk_st[mk_sp++] = (uint8_t)k; }
static int line_class(int c) {
    if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9')) return 1;
    switch (c) { case '*': case '#': return 2; case ':': case ';': return 3; case '|': case '!': return 4;
                 case '=': return 5; case '<': case '&': return 6; case ' ': return 7; default: return 0; }
}
static void mk_tag_end(void) {   /* a tag (raw <...> or &lt;...&gt;) just closed */
    mk_tag[mk_tn < 11 ? mk_tn : 11] = 0;
    if (mk_tagraw) {
        if (!strncmp(mk_tag, "text", 4)) { mk_intext = 1; mk_sp = 0; mk_inref = 0; }
        else if (!strncmp(mk_tag, "/text", 5)) { mk_intext = 0; mk_sp = 0; mk_inref = 0; }
    } else {
        if (!strncmp(mk_tag, "ref", 3) && (mk_tag[3] == 0 || mk_tag[3] == ' ')) mk_inref = 1;
        else if (!strncmp(mk_tag, "/ref", 4)) mk_inref = 0;
    }
    mk_intag = 0;
}
static void mk_open_tag(int raw) { mk_push(K_TAG); mk_intag = 1; mk_tn = 0; mk_tagraw = raw; }
static void mk_close_tag(int selfclose) {
    if (mk_top() == K_TAG) mk_sp--;
    if (mk_intag) { if (selfclose && !strncmp(mk_tag, "ref", 3)) mk_tn = 0; mk_tag_end(); }
}
static void mk_update(int c, uint64_t h) {   /* h = history including c */
    int pc = (int)((h >> 8) & 255);
    if (c == '\'') { mk_apos++; } else if (mk_apos) {
        if (mk_apos == 2) mk_ital ^= 1; else if (mk_apos == 3) mk_bold ^= 1; else if (mk_apos >= 5) { mk_ital ^= 1; mk_bold ^= 1; }
        mk_apos = 0;
    }
    if (mk_linestart && c != '\n') { mk_lc = line_class(c); mk_linestart = 0; }
    if (mk_intag && c != '>' && c != '&' && c != ';' && mk_tn < 11) mk_tag[mk_tn++] = (char)c;
    switch (c) {
    case '\n':
        mk_linestart = 1; mk_lc = 0; mk_ital = mk_bold = 0; mk_apos = 0;
        while (mk_sp && (mk_top() == K_LINK || mk_top() == K_EXT || mk_top() == K_TAG)) mk_sp--;
        mk_intag = 0; break;
    case '[': if (mk_top() == K_EXT && pc == '[') mk_st[mk_sp - 1] = K_LINK; else mk_push(K_EXT); break;
    case ']': if (mk_top() == K_EXT) mk_sp--; else if (mk_top() == K_LINK && pc == ']') mk_sp--; break;
    case '{': if (mk_top() == K_BR1 && pc == '{') mk_st[mk_sp - 1] = K_TMPL; else mk_push(K_BR1); break;
    case '|': if (mk_top() == K_BR1 && pc == '{') mk_st[mk_sp - 1] = K_TABLE; break;
    case '}':
        if (mk_top() == K_TABLE && pc == '|') mk_sp--;
        else if (mk_top() == K_TMPL && pc == '}') mk_sp--;
        else if (mk_top() == K_BR1) mk_sp--;
        break;
    case '<': mk_open_tag(1); break;
    case '>': if (mk_intag && mk_tagraw) mk_close_tag(pc == '/'); break;
    case ';':
        if ((h & 0xffffffffULL) == 0x266c743bULL) { mk_open_tag(0); }   /* &lt; */
        else if ((h & 0xffffffffULL) == 0x2667743bULL && mk_intag && !mk_tagraw) {                             /* &gt; */
            if (mk_tn >= 2) mk_tn -= 2;   /* drop the "gt" collected before the ; */
            mk_close_tag(mk_tn > 0 && mk_tag[mk_tn - 1] == '/');
        }
        break;
    }
    int top = mk_top(), dep = mk_sp < 3 ? mk_sp : 3;
    if (!mk_intext) mk_mode = 0;
    else if (top == K_TAG || mk_inref) mk_mode = 7;
    else if (top == K_LINK) mk_mode = 5;
    else if (top == K_TMPL) mk_mode = 6;
    else if (top == K_TABLE || top == K_BR1 || mk_lc == 4) mk_mode = 3;
    else if (mk_lc == 2 || mk_lc == 3) mk_mode = 2;
    else if (mk_lc == 5) mk_mode = 4;
    else mk_mode = 1;
    uint32_t st = (uint32_t)(top | dep << 3 | mk_lc << 5 | mk_intext << 8 | mk_inref << 9 | mk_ital << 10 | mk_bold << 11);
    ctxhX[0] = hash32_fwd(st * 0x2545F491U + (uint32_t)(h & 0xffff) + 0x6a09e667U);
    ctxhX[1] = hash32_fwd((st & 0xe07) * 0x9E3779B1U ^ hash32_fwd(wcur + (uint32_t)line_class(c) * 0x85EBCA77U + 0xbb67ae85U));
}

static inline uint32_t hash32(uint32_t x) {
    x ^= x >> 16; x *= 0x7feb352dU; x ^= x >> 15; x *= 0x846ca68bU; x ^= x >> 16; return x;
}

static void select_buckets(int dcode) {
    for (int i = 0; i < NH; i++) {
        if (i == 6 && !(FLAGS & 1)) { bucket[i] = NULL; continue; }
        uint32_t h = hash32(ctxh[i] + (uint32_t)dcode * 0x9E3779B1U + (uint32_t)i * 0x85EBCA77U);
        uint32_t idx = h >> (32 - TB[i]);
        uint8_t chk = (uint8_t)(h & 255);
        Slot *b = H[i] + ((size_t)idx << 3);
        if (XF & 16) bucket2[i] = H2[i] + ((size_t)idx << 3);
        if (b[0].n != chk || b[0].p != 1) { /* reset bucket */
            for (int k = 1; k < 8; k++) { b[k].p = 32768; b[k].n = 0; }
            b[0].n = chk; b[0].p = 1;
            if (XF & 16) for (int k = 1; k < 8; k++) bucket2[i][k] = 32768;
        }
        bucket[i] = b;
    }
    if (XF & 1) for (int i = 0; i < 2; i++) {
        uint32_t h = hash32(ctxhX[i] + (uint32_t)dcode * 0x9E3779B1U + (uint32_t)(i + 11) * 0x85EBCA77U);
        uint32_t idx = h >> (32 - TB[7 + i]); uint8_t chk = (uint8_t)(h & 255);
        Slot *b = HX[i] + ((size_t)idx << 3);
        if (XF & 16) bucket2[7 + i] = HX2[i] + ((size_t)idx << 3);
        if (b[0].n != chk || b[0].p != 1) { for (int k = 1; k < 8; k++) { b[k].p = 32768; b[k].n = 0; } b[0].n = chk; b[0].p = 1;
            if (XF & 16) for (int k = 1; k < 8; k++) bucket2[7 + i][k] = 32768; }
        bucketX[i] = b;
    }
}

static inline float st_f(int p16, int n) { return n ? stretch_t[p16 >> 4] * (1.0f / 256.0f) : 0.0f; }

static inline int mlen_bucket(int l) { return l < 16 ? l : l < 32 ? 16 + ((l - 16) >> 1) : l < 64 ? 24 + ((l - 32) >> 2) : 31; }

static int predict(int node, int j, int digit_idx) {
    cur_slot[NH] = &O0[node];
    xin[0] = st_f(O0[node].p, 1);
    for (int i = 0; i < NH; i++) {
        if (!bucket[i]) { xin[i + 1] = 0; cur_slot[i] = NULL; continue; }
        Slot *s = bucket[i] + j; cur_slot[i] = s;
        xin[i + 1] = st_f(s->p, s->n);
    }
    xin[IBIAS] = 1.0f;
    xin[NH + 2] = 0; xin[NH + 3] = 0; mctx = -1;
    if ((FLAGS & 16) && mvalid) {
        mbit = (mexp >> (7 - mbitpos)) & 1;
        mctx = mlen_bucket(mlen) * 2 + mbit;
        float s = stretch_t[mst[mctx].p >> 4] * (1.0f / 256.0f);
        float l = (mlen < 32 ? mlen : 32) * (1.0f / 8.0f);
        xin[NH + 2] = mbit ? s : -s;
        xin[NH + 3] = mbit ? l : -l;
    }
    wset = (FLAGS & 2) ? node : digit_idx;
    if (FLAGS & 8) { /* add count of seen high-order (2..6) slots: 0..5 */
        int k = 0; for (int i = 1; i < 6; i++) if (cur_slot[i] && cur_slot[i]->n) k++;
        wset = wset * 6 + k;
    }
#ifndef NOMSET   /* -DNOMSET: ablation, no match-length weight-set selection */
    if (FLAGS & 16) wset = wset * 4 + (!mvalid ? 0 : mlen < 16 ? 1 : mlen < 32 ? 2 : 3);
#endif
    xin[IMK] = 0; xin[IMK + 1] = 0;
    if (XF & 1) for (int i = 0; i < 2; i++) { Slot *s = bucketX[i] + j; cur_slotX[i] = s; xin[IMK + i] = st_f(s->p, s->n); }
    if (XF & 2) wset = wset * 8 + mk_mode;
    if (XF & 56) for (int m = 0; m < NM; m++) {   /* P1.3 */
        Slot *s = m < 7 ? cur_slot[m] : ((XF & 1) ? cur_slotX[m - 7] : NULL);
        xin[ISM + m] = 0; xin[ISL + m] = 0; xin[ICF + m] = 0; sm_i[m] = -1; cur2[m] = NULL;
        if (!s) continue;
        if ((XF & 32) && s->n >= LIMIT) xin[ICF + m] = st_f(s->p, 1);
        if (XF & 8) { sm_i[m] = ((m * 3 + digit_idx) * 13 + s->n) * 64 + (s->p >> 10); xin[ISM + m] = stretch_t[smt[sm_i[m]] >> 4] * (1.0f / 256.0f); }
        if (XF & 16) { cur2[m] = bucket2[m] + j; xin[ISL + m] = st_f(*cur2[m], s->n); }
    }
    xin[IBRAIN] = 0;
    if (FLAGS & 32) {  /* H3 brain: 10 model inputs + 6 context features */
        float bxv[BX]; int q = 0;
        for (int i = 0; i <= NH; i++) bxv[q++] = xin[i];
        bxv[q++] = xin[NH + 2]; bxv[q++] = xin[NH + 3];
        int k = 0; for (int i = 1; i < 6; i++) if (cur_slot[i] && cur_slot[i]->n) k++;
        bxv[q++] = digit_idx == 0; bxv[q++] = digit_idx == 1; bxv[q++] = digit_idx == 2;
        bxv[q++] = k * 0.2f; bxv[q++] = (!mvalid ? 0 : mlen < 16 ? 1 : mlen < 32 ? 2 : 3) * (1.0f / 3.0f);
        bxv[q++] = (digit_idx * 3 + (j >= 4 ? 2 : j >= 2 ? 1 : 0)) * (1.0f / 7.0f);
        xin[IBRAIN] = brain_forward(bxv);
    }
    float *w = Wt + (size_t)wset * NI, dot = 0;
    for (int i = 0; i < NIU; i++) dot += w[i] * xin[i];
    if (FLAGS & 64) dot = xin[IBRAIN];   /* replace mode: brain output instead of the logistic mixer */
    int d = (int)lrintf(dot * 256.0f);
    pr_mix = SQ(d);
    int p = pr_mix;
    if (FLAGS & 4) {
        int s = d; if (s > 2047) s = 2047; if (s < -2047) s = -2047;
        int pos = (s + 2048) * 32; int lo = pos >> 12; apm_w = pos & 4095;  /* 33 buckets over [-2048,2048) */
        apm_idx = ((int)(hist & 255) * 512 + node) * 33 + lo;
        int pa = (apm[apm_idx] * (4096 - apm_w) + apm[apm_idx + 1] * apm_w) >> 16; /* 12-bit */
        p = (pr_mix + 3 * pa) >> 2;
    }
    if (p < 1) p = 1; if (p > 4095) p = 4095;
    pr_final = p;
    if (dumpf || (XF & 64)) {   /* B1: 16 features for the offline brain (dump) and the frozen brain (XF bit6) */
        int k = 0; for (int i = 1; i < 6; i++) if (cur_slot[i] && cur_slot[i]->n) k++;
        for (int i = 0; i <= NH; i++) dfeat[i] = xin[i];          /* 0 order-0, 1..6 orders 1-6, 7 word */
        dfeat[8] = xin[NH + 2]; dfeat[9] = xin[NH + 3];            /* match */
        dfeat[10] = xin[IMK]; dfeat[11] = xin[IMK + 1];            /* markup */
        dfeat[12] = logf((float)p / (float)(4096 - p));            /* stretch of the final 12-bit p */
        dfeat[13] = (digit_idx * 3 + (j >= 4 ? 2 : j >= 2 ? 1 : 0)) * (1.0f / 7.0f);
        dfeat[14] = k * 0.2f; dfeat[15] = mk_mode * (1.0f / 7.0f);
    }
    if (XF & 64) {
        float z = dfeat[12] + fb_forward(dfeat);
        int q = (int)lrintf(4096.0f / (1.0f + expf(-z)));
        if (q < 1) q = 1; if (q > 4095) q = 4095;
        return q;
    }
    return p;
}

static void update(int bit) {
    if (dumpf && dcnt++ % 31 == 0) { float bf = (float)bit; fwrite(dfeat, 4, 16, dumpf); fwrite(&bf, 4, 1, dumpf); }
    float err = (float)bit - pr_mix * (1.0f / 4096.0f);
    float *w = Wt + (size_t)wset * NI; const float lr = LR;
    for (int i = 0; i < NIU; i++) w[i] += lr * err * xin[i];
    if (FLAGS & 32) brain_update(bit);
    if (XF & 24) { int tgt = bit ? 65535 : 0;   /* P1.3: before slot_upd, so n is the count used at predict time */
        for (int m = 0; m < NM; m++) {
            if (sm_i[m] >= 0) { int v = smt[sm_i[m]]; v += (tgt - v) >> 6; smt[sm_i[m]] = (uint16_t)v; }
            if (cur2[m]) { Slot *s = m < 7 ? cur_slot[m] : cur_slotX[m - 7];
                int r = s->n < LIMIT ? (int)recip[s->n] : 512; int v = *cur2[m]; v += (int)(((int64_t)(tgt - v) * r) >> 16); *cur2[m] = (uint16_t)v; }
        } }
    for (int i = 0; i < NH; i++) if (cur_slot[i]) slot_upd(cur_slot[i], bit);
    slot_upd(cur_slot[NH], bit);
    if (XF & 1) { slot_upd(cur_slotX[0], bit); slot_upd(cur_slotX[1], bit); }
    if (FLAGS & 4) {
        int tgt = bit ? 65535 : 0;
        if (apm_w < 2048) apm[apm_idx] += (tgt - apm[apm_idx]) / 64;
        else apm[apm_idx + 1] += (tgt - apm[apm_idx + 1]) / 64;
    }
    if (FLAGS & 16) {
        if (mctx >= 0) {
            Slot *s = &mst[mctx]; int ok = bit == mbit;
            int p = s->p; p += (int)(((int64_t)((ok ? 65535 : 0) - p) * recip[s->n]) >> 16);
            s->p = (uint16_t)p; if (s->n < MLIMIT) s->n++;
            if (!ok) mvalid = 0;
        }
        mbitpos++;
    }
}

static void match_update(int c) {
    mbuf[mpos & BMASK] = (uint8_t)c; mpos++;
    if (mlen > 0) {
        if (mexp == c) { if (mlen < 65535) mlen++; mptr++; } else mlen = 0;
    }
    if (mpos >= MINLEN) {
        uint32_t h = 0;
        for (int k = 1; k <= MINLEN; k++) h = hash32(h + mbuf[(mpos - k) & BMASK] + 0x3c6ef372U);
        h >>= (32 - MBITS);
        if (mlen == 0) {
            uint64_t cand = mtab[h];
            if (cand > 0 && mpos - cand < (1ULL << BUFBITS) - 256) {
                int l = 0;
                while (l < 255 && (uint64_t)l < cand && mbuf[(cand - 1 - l) & BMASK] == mbuf[(mpos - 1 - l) & BMASK]) l++;
                if (l >= MINLEN) { mlen = l; mptr = cand; }
            }
        }
        mtab[h] = (uint32_t)mpos;
    }
    if (mlen > 0) mexp = mbuf[mptr & BMASK];
    mvalid = mlen > 0; mbitpos = 0;
}

static void byte_update(int c) {
    hist = (hist << 8) | (uint64_t)c;
    for (int k = 1; k <= 6; k++) {
        uint64_t m = hist & ((k == 8) ? ~0ULL : ((1ULL << (8 * k)) - 1));
        ctxh[k - 1] = hash32((uint32_t)m ^ hash32((uint32_t)(m >> 32) + (uint32_t)k * 0x27d4eb2dU));
    }
    int lc = c;
    if (lc >= 'A' && lc <= 'Z') lc += 32;
    if (lc >= 'a' && lc <= 'z') wcur = hash32(wcur + (uint32_t)lc + 0x51ed27U);
    else if (wcur) { wprev = wcur; wcur = 0; }
    ctxh[6] = hash32(wcur ^ hash32(wprev + 0x1234567U));
}

static const int WD[3] = {3, 3, 2};
static int code_byte(AC *a, int enc, int c) {
    int digits[3], out = 0, shift = 8;
    for (int d = 0; d < 3; d++) {
        int w = WD[d], j = 1; shift -= w;
        int dcode = d == 0 ? 0 : d == 1 ? 1 + digits[0] : 9 + 8 * digits[0] + digits[1];
        select_buckets(dcode);
        int dig = enc ? (c >> shift) & ((1 << w) - 1) : 0;
        for (int k = w - 1; k >= 0; k--) {
            int node = d == 0 ? j : d == 1 ? 8 + 8 * digits[0] + j : 72 + 4 * (8 * digits[0] + digits[1]) + j;
            int p = predict(node, j, d), bit;
            if (enc) { bit = (dig >> k) & 1; enc_bit(a, p, bit); } else bit = dec_bit(a, p);
            update(bit);
            j = (j << 1) | bit;
        }
        digits[d] = j - (1 << w);
        out = (out << w) | digits[d];
    }
    byte_update(out);
    if (FLAGS & 16) match_update(out);
    if (XF) mk_update(out, hist);
    return out;
}

static void model_init(void) {
    for (int i = 0; i < NH; i++) {
        H[i] = calloc((size_t)8 << TB[i], sizeof(Slot));
        if (!H[i]) { fprintf(stderr, "oom\n"); exit(1); }
    }
    for (int i = 0; i < 512; i++) { O0[i].p = 32768; O0[i].n = 0; }
    NSETS = ((FLAGS & 2) ? 512 : 3) * ((FLAGS & 8) ? 6 : 1) * ((FLAGS & 16) ? 4 : 1) * ((XF & 2) ? 8 : 1);
    if (XF & 1) for (int i = 0; i < 2; i++) { HX[i] = calloc((size_t)8 << TB[7 + i], sizeof(Slot)); if (!HX[i]) { fprintf(stderr, "oom\n"); exit(1); } }
    Wt = malloc(sizeof(float) * NSETS * NI);
    for (int i = 0; i < NSETS * NI; i++) Wt[i] = (i % NI == IBRAIN) ? 0.0f : (i % NI >= ISM) ? 0.15f : 0.3f;
    NIU = (XF & 32) ? NI : (XF & 24) ? ICF : IMK + 2;
    if (XF & 8) for (int i = 0; i < NM * 3 * 13 * 64; i++) smt[i] = (uint16_t)((i & 63) * 1024 + 512);
    if (XF & 16) { for (int i = 0; i < NH; i++) { H2[i] = malloc(((size_t)8 << TB[i]) * 2); if (!H2[i]) { fprintf(stderr, "oom\n"); exit(1); } }
        for (int i = 0; i < 2; i++) { HX2[i] = malloc(((size_t)8 << TB[7 + i]) * 2); if (!HX2[i]) { fprintf(stderr, "oom\n"); exit(1); } } }
    if (FLAGS & 32) brain_init();
    if (FLAGS & 4) {
        apm = malloc(sizeof(uint16_t) * 256 * 512 * 33);
        for (int i = 0; i < 256 * 512; i++)
            for (int k = 0; k < 33; k++) { int v = SQ((k - 16) * 128) * 16; if (v > 65535) v = 65535; apm[i * 33 + k] = (uint16_t)v; }
    }
    if (FLAGS & 16) {
        mbuf = calloc((size_t)1 << BUFBITS, 1); mtab = calloc((size_t)1 << MBITS, sizeof(uint32_t));
        if (!mbuf || !mtab) { fprintf(stderr, "oom\n"); exit(1); }
        for (int i = 0; i < 64; i++) { mst[i].p = 32768; mst[i].n = 0; }
    }
    byte_update(0); hist = 0;
}

int main(int argc, char **argv) {
    if (argc < 4 || (argv[1][0] != 'c' && argv[1][0] != 'd')) { fprintf(stderr, "usage: cm c|d in out [FLAGS] [TBITS] [XF]\n"); return 1; }
    init_tables();
    FILE *fi = fopen(argv[2], "rb"), *fo = fopen(argv[3], "wb");
    if (!fi || !fo) { perror("open"); return 1; }
    AC a = {0, 0xffffffffu, 0, NULL};
    uint64_t n = 0;
    if (argv[1][0] == 'c') {
        FLAGS = argc > 4 ? atoi(argv[4]) : 3; TBITS = argc > 5 ? atoi(argv[5]) : 22;
        fseek(fi, 0, SEEK_END); n = (uint64_t)ftell(fi); fseek(fi, 0, SEEK_SET);
        XF = argc > 6 ? atoi(argv[6]) : 0; if (XF) FLAGS |= 128;
        for (int i = 0; i < 9; i++) TB[i] = TBITS;
        if (XF & 4) { const char *e = getenv("CM_TB"); /* P1.2: 9 comma-separated table bits */
            if (!e || sscanf(e, "%d,%d,%d,%d,%d,%d,%d,%d,%d", &TB[0], &TB[1], &TB[2], &TB[3], &TB[4], &TB[5], &TB[6], &TB[7], &TB[8]) != 9) { fprintf(stderr, "XF bit2 needs CM_TB=b1,..,b9\n"); return 1; } }
        putc(FLAGS, fo); if (FLAGS & 128) putc(XF, fo); putc(TBITS, fo); if (XF & 4) for (int i = 0; i < 9; i++) putc(TB[i], fo); for (int i = 0; i < 8; i++) putc((int)(n >> (8 * i)) & 255, fo);
        if (XF & 64) { const char *e = getenv("CM_BW"); FILE *g = e ? fopen(e, "rb") : NULL;
            if (!g || fread(fbh, 2, FB_NPAR, g) != FB_NPAR) { fprintf(stderr, "XF bit6 needs CM_BW=fp16 weight file (%d values)\n", FB_NPAR); return 1; }
            fclose(g); fwrite(fbh, 2, FB_NPAR, fo); }
    } else {
        FLAGS = getc(fi); XF = (FLAGS & 128) ? getc(fi) : 0; TBITS = getc(fi);
        for (int i = 0; i < 9; i++) TB[i] = (XF & 4) ? getc(fi) : TBITS;
        for (int i = 0; i < 8; i++) n |= (uint64_t)getc(fi) << (8 * i);
        if ((XF & 64) && fread(fbh, 2, FB_NPAR, fi) != FB_NPAR) { fprintf(stderr, "bad archive (weights)\n"); return 1; }
    }
    if (XF & 64) fb_load(fbh);
    if (FLAGS < 0 || FLAGS > 255 || XF < 0 || XF > 127 || TBITS < 10 || TBITS > 26) { fprintf(stderr, "bad header\n"); return 1; }
    for (int i = 0; i < 9; i++) if (TB[i] < 10 || TB[i] > 27) { fprintf(stderr, "bad table bits\n"); return 1; }
    if (FLAGS & 32) _mm_setcsr(_mm_getcsr() | 0x8040);  /* flush denormals to zero (FTZ+DAZ); same in encoder and decoder */
    if (argv[1][0] == 'c' && getenv("CM_DUMP")) { dumpf = fopen(getenv("CM_DUMP"), "wb"); if (!dumpf) { perror("CM_DUMP"); return 1; } }
    model_init();
    a.f = argv[1][0] == 'c' ? fo : fi;
    if (argv[1][0] == 'c') {
        int c; while ((c = getc(fi)) != EOF) code_byte(&a, 1, c);
        for (int i = 0; i < 4; i++) { putc(a.x1 >> 24, fo); a.x1 <<= 8; }
    } else {
        for (int i = 0; i < 4; i++) { int c = getc(fi); a.x = (a.x << 8) | (uint32_t)(c == EOF ? 0 : c); }
        for (uint64_t i = 0; i < n; i++) putc(code_byte(&a, 0, 0), fo);
    }
    fclose(fi); fclose(fo); if (dumpf) fclose(dumpf);
    return 0;
}
