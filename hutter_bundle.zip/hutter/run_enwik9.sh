#!/usr/bin/env bash
# Base-8 Hutter project: verified enwik9 round trip in a GitHub Codespace (or any Linux box).
# Usage: bash run_enwik9.sh MODE [STAGE]
#   MODE  A2    FLAGS 31 + XF 7, table bits A2 (needs ~3 GB RAM; best known enwik8 setting, ~1.3 h total expected)
#         B     FLAGS 31 + XF 7, table bits B (~2.6 GB; run-9 setting, 167,600,439 bytes expected)
#         brain B tables + frozen Wuwei brain (XF 71, weights brain_b1.f16 in this folder; ~7 h per pass expected)
#   STAGE all (default) | compress | decompress   (the archive stays on disk between stages)
# Everything runs one process at a time. Work dir: ~/hutwork (override with WORK=...).
# Test mode: INPUT=/path/to/small_file skips the enwik9 download and hash checks.
set -uo pipefail
MODE=${1:-A2}; STAGE=${2:-all}
HERE=$(cd "$(dirname "$0")" && pwd); WORK=${WORK:-$HOME/hutwork}; mkdir -p "$WORK"; cd "$WORK"
LOG="$WORK/run_$MODE.log"
say() { echo "[$(date -u +%H:%M:%S)] $*" | tee -a "$LOG"; }
ZIPSHA=99cdb5ac84392252d3f0912ccedd195bc95bd80cbef3b0cdf2eee4ad9a3b7a51
E9SHA=159b85351e5f76e60cbe32e04c677847a9ecba3adc79addab6f4c6c7aa3744bc
WSHA=b0134b3d4a7b898ef57c0eb0fcb011c3fd29cd278e5c3f0da32f1746d27955fa
case $MODE in
  A2) XF=7;  TB=18,22,23,24,24,24,25,24,23 ;;
  B)  XF=7;  TB=18,22,23,24,24,24,24,23,23 ;;
  brain) XF=71; TB=18,22,23,24,24,24,24,23,23 ;;
  *) echo "MODE must be A2, B or brain"; exit 1 ;;
esac
[ -n "${CM_TB:-}" ] && TB=$CM_TB   # test override
export CM_TB=$TB
say "mode $MODE stage $STAGE tables $TB; cores $(nproc); $(grep MemTotal /proc/meminfo)"
MEMKB=$(awk '/MemTotal/{print $2}' /proc/meminfo)
[ "$MEMKB" -lt 3600000 ] && [ -z "${CM_TB_OK:-}" ] && say "WARNING: under 3.6 GB RAM; this setting needs ~3 GB per process. Pick a bigger machine or MODE B."
# 1. build
gcc -O2 -o cm "$HERE/cm.c" -lm 2>>"$LOG" || { say "build failed"; exit 1; }
cp cm cm.strip && strip cm.strip; BIN=$(stat -c %s cm.strip); say "built cm, stripped binary $BIN bytes"
if [ "$MODE" = brain ]; then
  [ "$(sha256sum "$HERE/brain_b1.f16" | cut -d' ' -f1)" = "$WSHA" ] || { say "weights hash mismatch"; exit 1; }
  export CM_BW="$HERE/brain_b1.f16"; say "weights ok"
fi
# 2. data
if [ -n "${INPUT:-}" ]; then IN=$INPUT; say "TEST MODE input $IN"
else
  IN=$WORK/enwik9
  if [ ! -f "$IN" ] || [ "$(stat -c %s "$IN")" != 1000000000 ]; then
    say "downloading enwik9.zip"
    for t in 1 2 3; do curl -fL -o enwik9.zip https://github.com/Wuwei0-1/Dodeca-VZ/releases/download/Data/enwik9.zip && break; sleep 10; done
    [ "$(sha256sum enwik9.zip | cut -d' ' -f1)" = "$ZIPSHA" ] || { say "zip hash mismatch"; exit 1; }
    unzip -o -q enwik9.zip && rm -f enwik9.zip
  fi
  [ "$(sha256sum "$IN" | cut -d' ' -f1)" = "$E9SHA" ] || { say "enwik9 hash mismatch"; exit 1; }
  say "enwik9 verified"
fi
N=$(stat -c %s "$IN"); ARC=$WORK/archive_$MODE.cm; OUT=$WORK/decoded_$MODE
# run one cm process with a once-a-minute heartbeat (terminal output counts as codespace activity) and peak RSS
runcm() { # args: label, command...
  local label=$1; shift; local t0=$(date +%s)
  "$@" & local pid=$!; local peak=0
  local i=0
  while kill -0 $pid 2>/dev/null; do
    sleep 5; i=$((i+1))
    local r=$(awk '/VmHWM/{print $2}' /proc/$pid/status 2>/dev/null); [ "${r:-0}" -gt "$peak" ] && peak=$r
    [ $((i % 12)) -eq 0 ] && say "$label running, $(( $(date +%s) - t0 )) s, peak RSS ${peak} kB"
  done
  wait $pid; local rc=$?; ELAPSED=$(( $(date +%s) - t0 )); PEAK=$peak
  return $rc
}
if [ "$STAGE" = all ] || [ "$STAGE" = compress ]; then
  say "compress start"; runcm compress ./cm c "$IN" "$ARC" 31 22 $XF || { say "compress FAILED"; exit 1; }
  echo "$ELAPSED $PEAK" > "$WORK/compress_$MODE.time"
  say "compress done: $(stat -c %s "$ARC") bytes in $ELAPSED s"
fi
if [ "$STAGE" = all ] || [ "$STAGE" = decompress ]; then
  [ -f "$ARC" ] || { say "no archive $ARC"; exit 1; }
  say "decompress start"; runcm decompress ./cm d "$ARC" "$OUT" || { say "decompress FAILED"; exit 1; }
  DT=$ELAPSED; DP=$PEAK; read CT CP < "$WORK/compress_$MODE.time" 2>/dev/null || { CT=null; CP=null; }
  H=$(sha256sum "$OUT" | cut -d' ' -f1); H0=$(sha256sum "$IN" | cut -d' ' -f1)
  OK=false; [ "$H" = "$H0" ] && OK=true
  A=$(stat -c %s "$ARC")
  say "decoded sha256 $H"; say "input   sha256 $H0"; say "ROUND TRIP OK: $OK"
  RES=$(printf '{"mode":"%s","bytes_in":%d,"archive_bytes":%d,"bpb":%.4f,"stripped_binary_bytes":%d,"S":%d,"compress_s":%s,"decompress_s":%d,"peak_rss_kb_compress":%s,"peak_rss_kb_decompress":%d,"roundtrip_ok":%s,"machine":"%s cores"}' \
    "$MODE" "$N" "$A" "$(echo "8*$A/$N" | bc -l)" "$BIN" $((A+BIN)) "$CT" "$DT" "$CP" "$DP" "$OK" "$(nproc)")
  say "RESULT $RES"; echo "$RES" > "$WORK/RESULT_$MODE.json"
fi
