# Hutter run bundle (Base-8 project)
Files: cm.c, brain.h, fbrain.h (the compressor), brain_b1.f16 (frozen brain weights, 44,554 bytes, sha256 b0134b3d...55fa), run_enwik9.sh.
    bash run_enwik9.sh A2               # all stages, ~1.3 h expected
    bash run_enwik9.sh brain compress   # ~7 h expected; then: bash run_enwik9.sh brain decompress
Results: ~/hutwork/RESULT_<MODE>.json and ~/hutwork/run_<MODE>.log. Send those two files back.
