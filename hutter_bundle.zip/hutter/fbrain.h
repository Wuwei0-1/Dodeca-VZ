/* fbrain.h — B1 step 2: the frozen Wuwei brain (forward pass only) for cm.c XF bit6.
 * Same architecture, parameter layout and forward pass as brain_train.c (J's wuwei_trainable_brain.jsx, inDim 16):
 *   x~ = tanh(W_in x + b_in) (8); enc = W_enc x~ + b_enc (4); 4-qubit RX(enc) / CNOT ring / RY(theta) -> <Z> (4);
 *   20 router logits, top-4 softmax; 4 routed experts 8->64->8 SiLU; 8x8 gate; 1 output logit y.
 * Weights: 22,277 IEEE fp16 values stored in the archive after the header (read from env CM_BW at compress time).
 * Use: coded p' = squash(stretch(p) + y), with the 16 features of the B1 dump. Deterministic in encoder and decoder
 * (same binary, no -ffast-math). */
#define FB_X 16
#define FB_D 8
#define FB_Q 4
#define FB_E 20
#define FB_H 64
#define FB_K 4
#define FB_NPAR 22277
static float fbw[FB_NPAR];
static const float *fWin, *fbin, *fWenc, *fbenc, *fth, *fWr, *fbr, *fW1, *fb1, *fW2, *fb2, *fWg, *fbg, *fWo, *fbo;
static void fb_layout(void) {
    const float *q = fbw;
    fWin = q; q += FB_D * FB_X; fbin = q; q += FB_D; fWenc = q; q += FB_Q * FB_D; fbenc = q; q += FB_Q; fth = q; q += FB_Q;
    fWr = q; q += FB_E * FB_Q; fbr = q; q += FB_E; fW1 = q; q += FB_E * FB_H * FB_D; fb1 = q; q += FB_E * FB_H;
    fW2 = q; q += FB_E * FB_D * FB_H; fb2 = q; q += FB_E * FB_D; fWg = q; q += FB_D * FB_D; fbg = q; q += FB_D;
    fWo = q; q += FB_D; fbo = q; q += 1;
    if (q - fbw != FB_NPAR) { fprintf(stderr, "fbrain layout\n"); exit(1); }
}
static void fb_load(const uint16_t *h) { for (int i = 0; i < FB_NPAR; i++) { _Float16 v; memcpy(&v, &h[i], 2); fbw[i] = (float)v; } fb_layout(); }
static void fb_qcirc(const float *ang, float *q) {
    float re[16], im[16], c[FB_Q], s[FB_Q];
    for (int i = 0; i < FB_Q; i++) { c[i] = cosf(ang[i] * 0.5f); s[i] = sinf(ang[i] * 0.5f); }
    for (int b = 0; b < 16; b++) {
        float mr = 1, mi = 0;
        for (int i = 0; i < FB_Q; i++) {
            if ((b >> i) & 1) { float nr = mi * s[i], ni = -mr * s[i]; mr = nr; mi = ni; } else { mr *= c[i]; mi *= c[i]; }
        }
        re[b] = mr; im[b] = mi;
    }
    for (int i = 0; i < FB_Q; i++) {
        int t = (i + 1) & 3;
        for (int b = 0; b < 16; b++) if (((b >> i) & 1) && !((b >> t) & 1)) {
            int b2 = b | (1 << t); float tr = re[b], ti = im[b]; re[b] = re[b2]; im[b] = im[b2]; re[b2] = tr; im[b2] = ti;
        }
    }
    for (int i = 0; i < FB_Q; i++) {
        float cc = cosf(fth[i] * 0.5f), ss = sinf(fth[i] * 0.5f);
        for (int b = 0; b < 16; b++) if (!((b >> i) & 1)) {
            int b1 = b | (1 << i); float r0 = re[b], i0 = im[b], r1 = re[b1], i1 = im[b1];
            re[b] = cc * r0 - ss * r1; im[b] = cc * i0 - ss * i1; re[b1] = ss * r0 + cc * r1; im[b1] = ss * i0 + cc * i1;
        }
    }
    for (int o = 0; o < FB_Q; o++) {
        float z = 0;
        for (int b = 0; b < 16; b++) { float pb = re[b] * re[b] + im[b] * im[b]; z += ((b >> o) & 1) ? -pb : pb; }
        q[o] = z;
    }
}
static float fb_forward(const float *x) {
    float xt[FB_D], enc[FB_Q], q[FB_Q], lg[FB_E], rw[FB_K], tot[FB_D] = {0}; int sel[FB_K];
    for (int r = 0; r < FB_D; r++) { float a = fbin[r]; for (int k = 0; k < FB_X; k++) a += fWin[r * FB_X + k] * x[k]; xt[r] = tanhf(a); }
    for (int i = 0; i < FB_Q; i++) { float a = fbenc[i]; for (int k = 0; k < FB_D; k++) a += fWenc[i * FB_D + k] * xt[k]; enc[i] = a; }
    fb_qcirc(enc, q);
    for (int e = 0; e < FB_E; e++) { float a = fbr[e]; for (int o = 0; o < FB_Q; o++) a += fWr[e * FB_Q + o] * q[o]; lg[e] = a; }
    int used[FB_E] = {0};
    for (int k = 0; k < FB_K; k++) { int bi = -1; for (int e = 0; e < FB_E; e++) if (!used[e] && (bi < 0 || lg[e] > lg[bi])) bi = e; used[bi] = 1; sel[k] = bi; }
    float m4 = lg[sel[0]], s4 = 0;
    for (int k = 0; k < FB_K; k++) { rw[k] = expf(lg[sel[k]] - m4); s4 += rw[k]; }
    for (int k = 0; k < FB_K; k++) rw[k] /= s4;
    for (int k = 0; k < FB_K; k++) {
        int e = sel[k]; const float *W1 = fW1 + e * FB_H * FB_D, *b1v = fb1 + e * FB_H, *W2 = fW2 + e * FB_D * FB_H, *b2v = fb2 + e * FB_D;
        float a[FB_H];
        for (int u = 0; u < FB_H; u++) { float z = b1v[u]; for (int i = 0; i < FB_D; i++) z += W1[u * FB_D + i] * xt[i]; a[u] = z / (1.0f + expf(-z)); }
        for (int o = 0; o < FB_D; o++) { float v = b2v[o]; for (int u = 0; u < FB_H; u++) v += W2[o * FB_H + u] * a[u]; tot[o] += rw[k] * v; }
    }
    float y = fbo[0];
    for (int i = 0; i < FB_D; i++) { float g = fbg[i]; for (int j = 0; j < FB_D; j++) g += fWg[i * FB_D + j] * tot[j]; y += fWo[i] * g; }
    return y;
}
