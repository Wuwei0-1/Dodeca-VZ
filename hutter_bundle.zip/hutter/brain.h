/* brain.h — H3: Wuwei TitanMengerBrain gate as an online bit predictor for cm.c.
 * Spec: claude/hutter/HUTTER-ROADMAP.md "Wuwei brain spec" (from J's wuwei_trainable_brain.jsx).
 *   x~ = tanh(W_in x + b_in) in R^8                      (x: BX inputs, W_in near identity on first 8)
 *   enc = W_enc x~ + b_enc in R^4
 *   4-qubit state vector: RX(enc_i) each qubit, CNOT ring 0->1->2->3->0, RY(theta_i); q_o = <Z_o>
 *   l = W_r q + b_r in R^20; top-4; softmax over the 4 (others weight 0)
 *   experts e: n_e = W2_e SiLU(W1_e x~ + b1_e) + b2_e (8->64->8); h = sum r_e n_e
 *   g = W_gate h + b_gate (8x8); y = W_out g + b_out (one logit, p = sigmoid(y))
 * Training: online, one step per bit. Cross-entropy (target is a bit) + load balance
 *   lambda*N*sum pbar_e^2 (pbar = EMA of full softmax, rate 1/4096). Adam, global-norm clip 1,
 *   lazy Adam for experts (only routed experts step). Quantum angles: parameter-shift (+-pi/2).
 * Deterministic: same binary => same float ops in encoder and decoder.
 */
#include <math.h>
#ifndef BLR
#define BLR 0.022f
#endif
#ifndef BHID
#define BHID 64
#endif
#define BX 16
#define BD 8
#define NQ 4
#define NE 20
#define TOPK 4
#define LBL 0.04f

typedef struct { float w, m, v; } P;   /* parameter + Adam moments */
static P Win[BD][BX], bin_[BD], Wenc[NQ][BD], benc[NQ], th[NQ], Wr[NE][NQ], br_[NE];
static P W1[NE][BHID][BD], b1[NE][BHID], W2[NE][BD][BHID], b2[NE][BD];
static P Wg[BD][BD], bg[BD], Wo[BD], bo;
/* grads */
static float gWin[BD][BX], gbin[BD], gWenc[NQ][BD], gbenc[NQ], gth[NQ], gWr[NE][NQ], gbr[NE];
static float gW1[TOPK][BHID][BD], gb1[TOPK][BHID], gW2[TOPK][BD][BHID], gb2[TOPK][BD];
static float gWg[BD][BD], gbg[BD], gWo[BD], gbo;
/* forward cache */
static float bx[BX], bxt[BD], benc_v[NQ], bq[NQ], blog[NE], bpf[NE], bpbar[NE], br[TOPK];
static int bsel[TOPK];
static float bz1[TOPK][BHID], bhd[TOPK][BHID], bn[TOPK][BD], bh[BD], bgv[BD], by;
static long bstep;

static uint32_t brng = 12345u;
static float brand(void) { brng = brng * 1664525u + 1013904223u; return ((brng >> 8) * (1.0f / 16777216.0f)) * 2.0f - 1.0f; }

static void brain_init(void) {
    memset(Win, 0, sizeof Win);
    for (int i = 0; i < BD; i++) for (int j = 0; j < BX; j++) Win[i][j].w = 0.05f * brand() + (i == j ? 0.5f : 0.0f);
    for (int i = 0; i < NQ; i++) for (int j = 0; j < BD; j++) Wenc[i][j].w = 0.5f * brand();
    const float t0[NQ] = {0.8619f, 0.758f, 0.0541f, -0.6433f};
    for (int i = 0; i < NQ; i++) th[i].w = t0[i];
    for (int e = 0; e < NE; e++) for (int i = 0; i < NQ; i++) Wr[e][i].w = 1.0f * brand();
    for (int e = 0; e < NE; e++) {
        for (int k = 0; k < BHID; k++) for (int i = 0; i < BD; i++) W1[e][k][i].w = brand() * 0.6f;
        for (int o = 0; o < BD; o++) for (int k = 0; k < BHID; k++) W2[e][o][k].w = brand() * 0.15f;
    }
    for (int i = 0; i < BD; i++) for (int j = 0; j < BD; j++) Wg[i][j].w = (i == j ? 1.0f : 0.0f) + 0.05f * brand();
    for (int i = 0; i < BD; i++) Wo[i].w = 0.1f * brand();
    for (int e = 0; e < NE; e++) bpbar[e] = 1.0f / NE;
}

/* 4-qubit circuit: returns <Z_o>. qubit i = bit i of the basis index. */
static void qcirc(const float *ang, const float *thv, float *q) {
    float re[16], im[16];
    /* RX layer on |0000> gives a product state: each qubit (cos a/2, -i sin a/2) */
    float c[NQ], s[NQ];
    for (int i = 0; i < NQ; i++) { c[i] = cosf(ang[i] * 0.5f); s[i] = sinf(ang[i] * 0.5f); }
    for (int b = 0; b < 16; b++) {
        float mr = 1, mi = 0;   /* product of factors: c (bit 0) or -i s (bit 1) */
        for (int i = 0; i < NQ; i++) {
            if ((b >> i) & 1) { float nr = mi * s[i], ni = -mr * s[i]; mr = nr; mi = ni; }
            else { mr *= c[i]; mi *= c[i]; }
        }
        re[b] = mr; im[b] = mi;
    }
    /* CNOT ring: control i, target (i+1)%4 */
    for (int i = 0; i < NQ; i++) {
        int t = (i + 1) & 3;
        for (int b = 0; b < 16; b++) if (((b >> i) & 1) && !((b >> t) & 1)) {
            int b2 = b | (1 << t); float tr = re[b], ti = im[b]; re[b] = re[b2]; im[b] = im[b2]; re[b2] = tr; im[b2] = ti;
        }
    }
    /* RY(theta_i): [[c,-s],[s,c]] with half angles */
    for (int i = 0; i < NQ; i++) {
        float cc = cosf(thv[i] * 0.5f), ss = sinf(thv[i] * 0.5f);
        for (int b = 0; b < 16; b++) if (!((b >> i) & 1)) {
            int b1 = b | (1 << i);
            float r0 = re[b], i0 = im[b], r1 = re[b1], i1 = im[b1];
            re[b] = cc * r0 - ss * r1; im[b] = cc * i0 - ss * i1;
            re[b1] = ss * r0 + cc * r1; im[b1] = ss * i0 + cc * i1;
        }
    }
    for (int o = 0; o < NQ; o++) {
        float z = 0;
        for (int b = 0; b < 16; b++) { float pb = re[b] * re[b] + im[b] * im[b]; z += ((b >> o) & 1) ? -pb : pb; }
        q[o] = z;
    }
}

static inline float silu(float z) { return z / (1.0f + expf(-z)); }

static float brain_forward(const float *x) {
    for (int i = 0; i < BX; i++) bx[i] = x[i];
    for (int i = 0; i < BD; i++) { float a = bin_[i].w; for (int j = 0; j < BX; j++) a += Win[i][j].w * bx[j]; bxt[i] = tanhf(a); }
    for (int i = 0; i < NQ; i++) { float a = benc[i].w; for (int j = 0; j < BD; j++) a += Wenc[i][j].w * bxt[j]; benc_v[i] = a; }
    float thv[NQ]; for (int i = 0; i < NQ; i++) thv[i] = th[i].w;
    qcirc(benc_v, thv, bq);
    float mx = -1e30f;
    for (int e = 0; e < NE; e++) { float a = br_[e].w; for (int i = 0; i < NQ; i++) a += Wr[e][i].w * bq[i]; blog[e] = a; if (a > mx) mx = a; }
    float sum = 0; for (int e = 0; e < NE; e++) { bpf[e] = expf(blog[e] - mx); sum += bpf[e]; }
    for (int e = 0; e < NE; e++) bpf[e] /= sum;
    /* top-4 (ties broken by lower index) */
    int used[NE] = {0};
    for (int k = 0; k < TOPK; k++) { int bi = -1; for (int e = 0; e < NE; e++) if (!used[e] && (bi < 0 || blog[e] > blog[bi])) bi = e; used[bi] = 1; bsel[k] = bi; }
    float m4 = blog[bsel[0]], s4 = 0;
    for (int k = 0; k < TOPK; k++) { br[k] = expf(blog[bsel[k]] - m4); s4 += br[k]; }
    for (int k = 0; k < TOPK; k++) br[k] /= s4;
    for (int i = 0; i < BD; i++) bh[i] = 0;
    for (int k = 0; k < TOPK; k++) {
        int e = bsel[k];
        for (int u = 0; u < BHID; u++) { float a = b1[e][u].w; for (int i = 0; i < BD; i++) a += W1[e][u][i].w * bxt[i]; bz1[k][u] = a; bhd[k][u] = silu(a); }
        for (int o = 0; o < BD; o++) { float a = b2[e][o].w; for (int u = 0; u < BHID; u++) a += W2[e][o][u].w * bhd[k][u]; bn[k][o] = a; bh[o] += br[k] * a; }
    }
    for (int i = 0; i < BD; i++) { float a = bg[i].w; for (int j = 0; j < BD; j++) a += Wg[i][j].w * bh[j]; bgv[i] = a; }
    float y = bo.w; for (int i = 0; i < BD; i++) y += Wo[i].w * bgv[i];
    if (y > 7.99f) y = 7.99f; if (y < -7.99f) y = -7.99f;
    by = y;
    return y;
}

static inline void adam(P *p, float g, float lr, float c1, float c2) {
    p->m = 0.9f * p->m + 0.1f * g; p->v = 0.999f * p->v + 0.001f * g * g;
    p->w -= lr * (p->m * c1) / (sqrtf(p->v * c2) + 1e-8f);
}

static void brain_update(int bit) {
    float py = 1.0f / (1.0f + expf(-by));
    float dy = py - (float)bit;
    float ss = 0;  /* sum of squared grads for global-norm clip */
    gbo = dy; ss += dy * dy;
    float dg[BD];
    for (int i = 0; i < BD; i++) { gWo[i] = dy * bgv[i]; ss += gWo[i] * gWo[i]; dg[i] = dy * Wo[i].w; }
    float dh[BD] = {0};
    for (int i = 0; i < BD; i++) { gbg[i] = dg[i]; ss += dg[i] * dg[i]; for (int j = 0; j < BD; j++) { gWg[i][j] = dg[i] * bh[j]; ss += gWg[i][j] * gWg[i][j]; dh[j] += Wg[i][j].w * dg[i]; } }
    float dxt[BD] = {0}, dr[TOPK];
    for (int k = 0; k < TOPK; k++) {
        int e = bsel[k]; float dn[BD], drk = 0;
        for (int o = 0; o < BD; o++) { dn[o] = br[k] * dh[o]; drk += dh[o] * bn[k][o]; }
        dr[k] = drk;
        float dhd[BHID] = {0};
        for (int o = 0; o < BD; o++) { gb2[k][o] = dn[o]; ss += dn[o] * dn[o];
            for (int u = 0; u < BHID; u++) { float gg = dn[o] * bhd[k][u]; gW2[k][o][u] = gg; ss += gg * gg; dhd[u] += W2[e][o][u].w * dn[o]; } }
        for (int u = 0; u < BHID; u++) {
            float z = bz1[k][u], sg = 1.0f / (1.0f + expf(-z));
            float dz = dhd[u] * (sg * (1.0f + z * (1.0f - sg)));
            gb1[k][u] = dz; ss += dz * dz;
            for (int i = 0; i < BD; i++) { float gg = dz * bxt[i]; gW1[k][u][i] = gg; ss += gg * gg; dxt[i] += W1[e][u][i].w * dz; }
        }
    }
    /* router logits: top-4 softmax grad + load-balance grad through the full softmax */
    float dl[NE] = {0};
    float sdr = 0; for (int k = 0; k < TOPK; k++) sdr += br[k] * dr[k];
    for (int k = 0; k < TOPK; k++) dl[bsel[k]] += br[k] * (dr[k] - sdr);
    for (int e = 0; e < NE; e++) bpbar[e] += (bpf[e] - bpbar[e]) * (1.0f / 4096.0f);
    float glb[NE], sg = 0;
    for (int e = 0; e < NE; e++) { glb[e] = 2.0f * LBL * NE * bpbar[e]; sg += bpf[e] * glb[e]; }
    for (int e = 0; e < NE; e++) dl[e] += bpf[e] * (glb[e] - sg);
    float dq[NQ] = {0};
    for (int e = 0; e < NE; e++) { gbr[e] = dl[e]; ss += dl[e] * dl[e]; for (int i = 0; i < NQ; i++) { gWr[e][i] = dl[e] * bq[i]; ss += gWr[e][i] * gWr[e][i]; dq[i] += Wr[e][i].w * dl[e]; } }
    /* parameter-shift gradients for enc angles and theta */
    float thv[NQ], ang[NQ], qp[NQ], qm[NQ], denc[NQ];
    for (int i = 0; i < NQ; i++) { thv[i] = th[i].w; ang[i] = benc_v[i]; }
    const float H = 1.5707963267948966f;
    for (int i = 0; i < NQ; i++) {
        float sv = ang[i]; ang[i] = sv + H; qcirc(ang, thv, qp); ang[i] = sv - H; qcirc(ang, thv, qm); ang[i] = sv;
        float d = 0; for (int o = 0; o < NQ; o++) d += dq[o] * 0.5f * (qp[o] - qm[o]); denc[i] = d;
        sv = thv[i]; thv[i] = sv + H; qcirc(ang, thv, qp); thv[i] = sv - H; qcirc(ang, thv, qm); thv[i] = sv;
        d = 0; for (int o = 0; o < NQ; o++) d += dq[o] * 0.5f * (qp[o] - qm[o]); gth[i] = d; ss += d * d;
    }
    for (int i = 0; i < NQ; i++) { gbenc[i] = denc[i]; ss += denc[i] * denc[i]; for (int j = 0; j < BD; j++) { gWenc[i][j] = denc[i] * bxt[j]; ss += gWenc[i][j] * gWenc[i][j]; dxt[j] += Wenc[i][j].w * denc[i]; } }
    for (int i = 0; i < BD; i++) { float da = dxt[i] * (1.0f - bxt[i] * bxt[i]); gbin[i] = da; ss += da * da; for (int j = 0; j < BX; j++) { gWin[i][j] = da * bx[j]; ss += gWin[i][j] * gWin[i][j]; } }
    float sc = ss > 1.0f ? 1.0f / sqrtf(ss) : 1.0f;
    /* Adam step */
    bstep++;
    float lr = BLR;
    float c1 = 1.0f / (1.0f - powf(0.9f, (float)(bstep < 100000 ? bstep : 100000)));
    float c2 = 1.0f / (1.0f - powf(0.999f, (float)(bstep < 100000 ? bstep : 100000)));
    adam(&bo, gbo * sc, lr, c1, c2);
    for (int i = 0; i < BD; i++) { adam(&Wo[i], gWo[i] * sc, lr, c1, c2); adam(&bg[i], gbg[i] * sc, lr, c1, c2); for (int j = 0; j < BD; j++) adam(&Wg[i][j], gWg[i][j] * sc, lr, c1, c2); }
    for (int k = 0; k < TOPK; k++) {
        int e = bsel[k];
        for (int o = 0; o < BD; o++) { adam(&b2[e][o], gb2[k][o] * sc, lr, c1, c2); for (int u = 0; u < BHID; u++) adam(&W2[e][o][u], gW2[k][o][u] * sc, lr, c1, c2); }
        for (int u = 0; u < BHID; u++) { adam(&b1[e][u], gb1[k][u] * sc, lr, c1, c2); for (int i = 0; i < BD; i++) adam(&W1[e][u][i], gW1[k][u][i] * sc, lr, c1, c2); }
    }
    for (int e = 0; e < NE; e++) { adam(&br_[e], gbr[e] * sc, lr, c1, c2); for (int i = 0; i < NQ; i++) adam(&Wr[e][i], gWr[e][i] * sc, lr, c1, c2); }
    for (int i = 0; i < NQ; i++) { adam(&th[i], gth[i] * sc, lr, c1, c2); adam(&benc[i], gbenc[i] * sc, lr, c1, c2); for (int j = 0; j < BD; j++) adam(&Wenc[i][j], gWenc[i][j] * sc, lr, c1, c2); }
    for (int i = 0; i < BD; i++) { adam(&bin_[i], gbin[i] * sc, lr, c1, c2); for (int j = 0; j < BX; j++) adam(&Win[i][j], gWin[i][j] * sc, lr, c1, c2); }
}
